@extends('layouts.app')

@section('content')
<div class="account">
    <h1>My Account</h1><br>
    <a href="/patient/my-appointments" >My Appointments</a><br>
    <a href="/patient/my-details" >My Details</a>
</div>
@endsection