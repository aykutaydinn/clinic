

<?php $__env->startSection('content'); ?>
<div class="account">
    <h1>My Account</h1><br>
    <a href="/patient/my-appointments" >My Appointments</a><br>
    <a href="/patient/my-details" >My Details</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/patient/my-account.blade.php ENDPATH**/ ?>