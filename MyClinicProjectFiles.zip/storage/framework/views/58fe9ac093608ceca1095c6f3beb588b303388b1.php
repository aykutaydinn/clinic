
<link rel="stylesheet" href="/css/appoint.css">

<?php $__env->startSection('content'); ?>

<div class="banner3">
  <div class="py-5 banner" style="background-image:url(https://www.wrappixel.com/demos/ui-kit/wrapkit/assets/images/form-banners/banner2/banner-bg.jpg);">
    <div class="container">
      <div class="row">
        <div class="col-md-7 col-lg-5">
          <h2 style="color: white!important;">APPOINTMENT INFORMATION</h2>
          <div class="bg-white">
          <form action = "/appointment/selectdoctor/book" method = "post">
<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
<input type = "hidden" name = "dateTime" value = "<?php echo e($dateTime); ?>">
<input type = "hidden" name = "appType" value = "<?php echo e($apType); ?>">
<input type = "hidden" name = "pID" value = "<?php echo e($pId); ?>">
              <div class="form-row border-bottom p-4">
                <label class="text-inverse font-12 text-uppercase">Appointment Date</label>
                <input type="text" class="border-0 p-0 font-14 form-control" value="<?php echo e($strDateTime); ?>" readonly/>
              </div>
            <div class="form-row border-bottom p-4">
              <label class="text-inverse font-12 text-uppercase">Patient Name</label>
              <input type="text" class="border-0 p-0 font-14 form-control" value="<?php echo e($pName); ?>" readonly/>
            </div>
            <div class="form-row border-bottom p-4">
              <label class="text-inverse font-12 text-uppercase">Patient Email</label>
              <input type="text" class="border-0 p-0 font-14 form-control" value="<?php echo e($pEmail); ?>" readonly/>
            </div>
            <?php if($pPhoneNo!=null): ?>
            <div class="form-row border-bottom p-4">
              <label class="text-inverse font-12 text-uppercase">Patient Phone Number</label>
              <input type="text" class="border-0 p-0 font-14 form-control" value="<?php echo e($pPhoneNo); ?>" readonly/>
            </div>
            <?php endif; ?>
            <div class="form-row border-bottom p-4 position-relative">
              <label class="text-inverse font-12 text-uppercase">Please choose one of the available doctors</label>
              <div class="input-group date">
              <select name="selectedDoctor" id="selectedDoctor">
<?php $__currentLoopData = $availableDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($doctor->doctor->id); ?> "><?php echo e($doctor->doctor->name); ?> - <?php echo e($doctor->doctor->doctorType); ?> </option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
              </div>
            </div>
            <div>
              <button class="m-0 border-0 py-4 font-14 font-weight-medium btn btn-danger-gradiant btn-block position-relative rounded-0 text-center text-white text-uppercase">
									<span>Confirm Your Appointment Now</span>
							</button>
            </div>
</div>
</form>
</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/pages/selectdoctor.blade.php ENDPATH**/ ?>