

<?php $__env->startSection('content'); ?>
<div class="signup">
<div class="appointmentcontainer">
    <h1>About</h1>
    MyClinic <br>
    About text will come here...
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3309.0925011088784!2d151.0853350150623!3d-33.96446188062988!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12b90c11d8bd85%3A0xd38d49c13ff1af82!2s43%20Penshurst%20St%2C%20Penshurst%20NSW%202222!5e0!3m2!1sen!2sau!4v1612674387835!5m2!1sen!2sau" width="500" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pages/about.blade.php ENDPATH**/ ?>