

<?php $__env->startSection('content'); ?>
<div class="signup">
<div class="appointmentcontainer">
    <h1>My Account</h1>
    <li><a class="menu " href="/patient/my-appointments" >My Appointments</a></li>
    <li><a class="menu " href="/patient/my-details" >My Details</a></li>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/patient/my-account.blade.php ENDPATH**/ ?>