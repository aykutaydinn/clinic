<style> 
.col-form-label {
    color: #2A4A8D;
    font-family: Lato,"helvetica neue",sans-serif;
}

.col-form-title {
    color: #2A4A8D;
    font-family: Lato,"helvetica neue",sans-serif;
    font-weight: 400;
    font-variant: small-caps;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="container">

<!-- Form Name -->
<h1>Appointment Details</h1>

<!-- Text input-->
<div class="form-group row">
  <label class="col-md-4 col-form-label">Reference Number</label>  
  <div class="col-md-4">
  <label><?php echo e($appointment[0]->id); ?></label>
    
  </div>
</div>

<!-- Text input-->
<div class="form-group row">
  <label class="col-md-4 col-form-label" for="preferred_name">Date:</label>  
  <div class="col-md-4">
  <label><?php echo e($appointment[0]->dateOfAppointment); ?></label>
    
  </div>
</div>

<div class="form-group row">
  <label class="col-md-4 col-form-label" for="Patient Name">Patient Name:</label>  
  <div class="col-md-4">
  <label><?php echo e($appointment[0]->patient->name); ?></label>
    
  </div>
</div>

<div class="form-group row">
<form action="/doctor/manage-appointments/delete/<?php echo e($appointment[0]->id); ?>" method="POST">
<?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>

  <label class="col-md-4 col-form-label" for="next"></label>
  <div class="col-md-4">
    <button class="btn btn-danger">Cancel Appointment</button>
  </div>
</form>
</div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.doctor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/doctor/appointmentdetails.blade.php ENDPATH**/ ?>